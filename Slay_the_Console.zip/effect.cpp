#include "effect.h"
Effect::Effect(EffectType t, int m)
    :type(t), magnitude(m){}

void Effect::applyEffect(){
    // switch(type){
    //     case EffectType::damage: target.changeAttribute(PlayerAttribute::HP, -magnitude); break;
    //     case EffectType::block: target.changeAttribute(PlayerAttribute::block, magnitude); break;
    //     case EffectType::draw: 
    //         target.addToPlayerPile(PileType::hand, target.getCardFromPile(PileType::draw, 0)); 
    //         break;
    //     case EffectType::discard: target.removeFromPlayerPile(PileType::hand, 0); break;
    //     case EffectType::exhaust: target.addToPlayerPile(PileType::exhaust, target.getCardFromPile(PileType::hand, 0)); break;
    //     case EffectType::energy: target.changeAttribute(PlayerAttribute::energy, magnitude); break;
    // }

}